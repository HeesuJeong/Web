package com.ssafy;
import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Kickboard {

	static int[] dx= {-1,1,0,0};
	static int[] dy= {0,0,-1,1};
	static int H;
	static int W;
	static int[][] map;
	static boolean inMap(int x,int y){
		return (x>=1&&x<=H&&y>=1&&y<=W);
	}
	static int result;
	//static Queue<Point> q;
		public static int execute(File path) throws FileNotFoundException {
			result = 0;
			Scanner sc = new Scanner(path);
			//q=new LinkedList<>();
			
			H=sc.nextInt();//행 수
			W=sc.nextInt();//열 수
			map=new int[H+1][W+1];
			for (int i = 1; i <=H; i++) {
				for (int j = 1; j <=W; j++) {
					map[i][j]=sc.nextInt();
				}
			}
			
			dfs(1,1);
			return result;
		}
		static void dfs(int x,int y) {
			if(x==H&&y==W) result++;
			for(int i=0;i<4;i++) {
				int nx=x+dx[i];
				int ny=y+dy[i];
				if(inMap(nx, ny)&&(map[x][y]>map[nx][ny])) {
					dfs(nx,ny);
				}
			}
		}

		public static void main(String[] args) throws FileNotFoundException {
			System.out.println(execute(new File("input.txt")));
		}

}
