package com.ssafy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Count {

	static class info{
		String str;
		int cnt;
		public info(String str,int cnt) {
			// TODO Auto-generated constructor stub
			this.str=str;
			this.cnt=cnt;
		}
	}
	public String execute(String book) {
		String word = "";
		
		String input=book.toLowerCase();
		
		String[] arr=input.split(" ");
		ArrayList<info> li=new ArrayList<>();
		li.add(new info(arr[0],1));
		for (int i = 1; i < arr.length; i++) {
			String str=arr[i];
			boolean flag=false;
			for (int j = 0; j < li.size(); j++) {
				//이미 존재하는게 있다면
				if(li.get(j).str.equals(str)) {
					flag=true;
					li.get(j).cnt++;
					break;
				}
			}
			//존재하는게 없다면
			if(flag==false) {
				li.add(new info(str,1));
			}
		}
		
		
		Collections.sort(li,new Comparator<info>() {

			@Override
			public int compare(info o1, info o2) {
				// TODO Auto-generated method stub
				return o2.cnt-o1.cnt;
			}
		});
		int maxNum=li.get(0).cnt;
		int idx=0;
		char tmp=li.get(0).str.charAt(0);
		for (int i = 1; i < li.size(); i++) {
			if(maxNum==li.get(i).cnt) {
				
				if(tmp>li.get(i).str.charAt(0)) {
				idx=i;
				}
			}
		}
		
		System.out.println(li.get(idx).str);
		return word;
	}
	

	public static void main(String[] args) {
		String book1 ="Can Danny and his father outsmart the villainous Mr. Hazell? Danny has a life any boy would love - his home is a gypsy caravan, he's the youngest master car mechanic around, and his best friend is his dad, who never runs out of wonderful stories to tell. But one night Danny discovers a shocking secret that his father has kept hidden for years. "; 
		String book2 ="Soon Danny finds himself the mastermind behind the most incredible plot ever attempted against nasty Victor Hazell, a wealthy landowner with a bad attitude. Can they pull it off? If so, Danny will truly be the champion of the world.";
		String book3 ="I like cat. I like cat. I like cat. ";
		Count c = new Count();
		System.out.println(c.execute(book1));
		//System.out.println("=========");
		System.out.println(c.execute(book2));
		//System.out.println("=========");
		
		System.out.println(c.execute(book3));

	}

}
