package edu.ssafy.model;

import java.sql.SQLException;
import java.util.List;

import org.w3c.dom.Element;

public interface IFoodManager{

	public List<FoodVO> getFoodList();
	
	public FoodVO getFood(int code);
	public FoodVO getFoodname(String name);
	public List<FoodVO> getFoodnamelist(String name);
	public void loadData(String url) throws SQLException;
	public List<FoodVO> productparsing(String url);
	public String getTagValue(String tag, Element eElement);

	List<FoodVO> getFoodmaker(String maker);
}
